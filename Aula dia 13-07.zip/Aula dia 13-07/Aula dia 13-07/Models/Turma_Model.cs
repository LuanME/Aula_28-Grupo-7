﻿
namespace Aula_dia_13_07.Models
{
    public class Turma_Model
    {
        public string nome { get; set; }
        public string sobrenome { get; set; }
        public string status { get; set; }
    }
}
