﻿using Aula_dia_13_07.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aula_dia_13_07.Controllers
{
    public class TurmaController : Controller
    {
        public IActionResult Index()
        {
            List<Turma_Model> turma = new List<Turma_Model>();

            turma.Add(new Turma_Model()
            {
                nome = "Williaam",
                sobrenome = "Santa Anna",
                status = "Reprovado"
            });

            turma.Add(new Turma_Model()
            {
                nome = "Tiago",
                sobrenome = "Machado",
                status = "Aprovado"
            });

            return View(turma);
        }
    }
}
